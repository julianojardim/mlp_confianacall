import pygame
import menu

menu = menu.Menu()
menu.start()